# eng2kor
파이썬으로 한영타변환
