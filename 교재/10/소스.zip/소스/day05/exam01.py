'''
 제어문 : 조건에 따라 흐름을 제어하겠다.
 제어문 -> 조건문 : if
 제어문 -> 반복문 : for, while
 제어문 -> 그 외 : break, continue
 '''