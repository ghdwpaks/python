float_data = 3.14

print('실수형 변수 :', float_data)
print('실수형 변수 : %.2f' % float_data)
print('실수형 변수 : {:.2f}'.format(float_data))

float_data = float_data + 1.11
print('실수형 변수 : {:.2f}'.format(float_data))