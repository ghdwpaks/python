string_data = "문자열"
print('문자열 변수 :', string_data)
print('문자열 변수 : %s' % string_data)
print('문자열 변수 : {}'.format(string_data))

string_data = string_data + "문자열"
print('문자열 변수 : {}'.format(string_data))