
print('1. easy game')
print('2. hard game')
print('3. exit')

data = int(input('선택 : '))

if data == 1 :
    print('easy game start')
if data == 2 : 
    print('hard game start')
if data == 3 :
    print('game exit')