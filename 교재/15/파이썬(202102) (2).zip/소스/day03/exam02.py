data = 100
print('정수형 변수 :', data)
print('정수형 변수 : %d' % data)
print('정수형 변수 : {}'.format(data))

data = data + 100
print('정수형 변수 : {}'.format(data))