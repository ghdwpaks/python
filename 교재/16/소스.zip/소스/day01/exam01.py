# 주석 단축키 : Ctrl + /
# Ctrl + Alt + n : 코드 실행 

# print('hello Python') 
# print("hello Python") 
# print(10 + 20)
# print(10 * 2)
# print(10 / 3)
# print(10 - 3)
# print('10 더하기 20 = ', 10 + 20)
# print("10 곱하기 2 = ", 10 * 2)
# print('10 나누기 3 = ', 10 / 3)
# print('10 빼기 3 = ', 10 - 3)
# print('저의 이름은 \'홍길동\' 입니다.')
# print('저의 나이는 20살 입니다.')
# print('주소는 산골자기 입니다.')
print('12 + 54 = ', 12 + 54, '입니다.')
print('268 - 42 =',  268 - 42, '입니다.')
print('2 * 23 =  ', 2 * 23, '입니다.')
print('120 / 3 = ', 120 / 3, '입니다.')


