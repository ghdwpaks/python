
data1 = '123'
print('data1({}) : {}'.format(data1, type(data1)))

data1 = int(data1)
print('data1({}) : {}'.format(data1, type(data1)))

data1 = float(data1)
print('data1({}) : {}'.format(data1, type(data1)))

data1 = str(data1)
print('data1({}) : {}'.format(data1, type(data1)))