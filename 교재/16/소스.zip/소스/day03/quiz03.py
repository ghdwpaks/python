# 다음과 같이 나오도록 코딩하시오.정수 데이터는 변수를 사용하세요.
# 파이썬 100점
# 나는 27살이다.

score = 100
print('파이썬', score, '점')
print('파이썬 {}점'.format(score))
print('파이썬 %d점' % score)

age = 27
print('나는 %d살이다.' % age)
print('나는 {}살이다.'.format(age))