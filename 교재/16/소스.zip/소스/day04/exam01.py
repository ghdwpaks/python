
print('데이터 입력 : ', end='')
in_data = input()
print('입력 데이터 : {}'.format(in_data))

in_data = input('데이터 입력 : ')
print('입력 데이터 : {}'.format(in_data))