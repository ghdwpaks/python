

data = [1,2,3,4,5]
print(data)
print()

data = range(10)
print(data)
print()

data = list(range(10))
print(data)

for i in data :
    print('i : {}, '.format(i), end='')
print()

data = [2,5,10,15,7, 'string', 3.14]
for i in data :
    print('i : {}, '.format(i), end='')
