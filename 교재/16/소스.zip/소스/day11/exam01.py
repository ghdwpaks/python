
# 1 ~ 10까지 합계를 구하자

i = 1; total = 0
while i <= 10 :
    total = total + i # total += i
    i = i + 1 # i += 1

print('1 ~ 10의 합계 : {}'.format(total))