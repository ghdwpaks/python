data1, data2, data3 = 1, 1.1, '문자열'

# type()는 변수의 데이터 자료형을 파악하는 용도로 사용.
print('{}'.format(type(data1)))
print('{}'.format(type(data2)))
print('{}'.format(type(data3)))

print('{}'.format(type(data1)))
data1 = 2.2
print('{}'.format(type(data1)))
data1 = 'string'
print('{}'.format(type(data1)))