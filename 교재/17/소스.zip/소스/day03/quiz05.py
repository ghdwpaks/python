# 출발역에서 도착역까지 11개의 지하철 역을 지나왔다.  
# 총 37분이 걸렸다면 한 역을 지나는데 걸리는 시간을 구해서 출력하시오.
total_station = 11
total_minute = 37
average_time = total_minute / total_station
print('한 역의 평균 시간은 {:.2f}분 입니다.'.format(average_time))
