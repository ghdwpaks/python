data1 = input('데이터 입력 : ')
data2 = input('데이터 입력 : ')

print('출력 : {}, {}'.format(data1, data2))
print('자료형 : {}, {}'.format( type(data1), type(data2)))