data1 = data2 = 5
# 복합 대입 연산자
data1 += 1 # += : data1 = data1 + 1
print("data1 + 1 = " , data1)

data1 -= 1 # -= : data1 = data1 - 1
print("data1 - 1 = ", data1)

data1 *= data2 # *= : data1 = data1 * data2
print("data1 * data2 = ", data1)

data1 //= data2 # //= : data1 = data1 // data2
print("data1 // data2 = ", data1)

data1 %= data2 # %= : data1 = data1 % data2
print("data1 % data2 = ", data1)
