
data = input('정수 입력 : ')
data = int(data)

# if data > 10 :
#     print('{}는/은 10보다 크다.'.format(data))

if data > 0 and data <= 100 :
    print('{}는/은 1~100 범위 안에 정수 입니다.'.format(data))