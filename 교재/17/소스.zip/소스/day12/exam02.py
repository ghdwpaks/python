

for i in range(3) :
    for j in range(5) :
        print('{} x {} = {}'.format(i, j, i*j))
print()
print()

# 구구단 2~9단 까지 출력해주세요
for i in range(2, 10) :
    for j in range(1, 10) :
        print('{} x {} = {}'.format(i, j, i*j))
