'''
리스트 
 - 인덱싱
 list_data = [10,20,30,40]
 시작은 0부터 순차적으로 데이터 한 개씩 접근이 가능하다.

'''
list_data = [10,20,30,40]

print('list_data[0] : ', list_data[0])
print('list_data[1] : ', list_data[1])
print('list_data[2] : ', list_data[2])
print('list_data[3] : ', list_data[3])

print('list_data[-1] : ', list_data[-1])
print('list_data[-2] : ', list_data[-2])
print('list_data[-3] : ', list_data[-3])
print('list_data[-4] : ', list_data[-4])