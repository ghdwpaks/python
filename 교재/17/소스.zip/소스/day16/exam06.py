url = {}
url['파이썬'] = 'www.python.org'
url['네이버'] = 'www.naver.com'
url['구글'] = 'www.google.com'

key = input('사이트 이름 : ')
value = input('사이트 이름의 URL : ')
url[key] = value

print(url)