user_id = 'kyes'

print('##### 인증 프로그램 #####')
check_id = input('ID : ')

if user_id == check_id :
    print('인증 성공')
else :
    print('인증 실패')