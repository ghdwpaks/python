

string_data = 'string'
for s in string_data :
    print(s)