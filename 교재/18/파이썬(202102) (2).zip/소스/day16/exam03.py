tuple_data = 10,20,30,20,10

print('tuple_data 중 10의 개수는 : ', tuple_data.count(10))
print('tuple_data 중 20의 개수는 : ', tuple_data.count(20))
print('tuple_data 중 30의 개수는 : ', tuple_data.count(30))

print('tuple_data 중 10의 위치는 : ', tuple_data.index(10))
print('tuple_data 중 20의 위치는 : ', tuple_data.index(20))
print('tuple_data 중 30의 위치는 : ', tuple_data.index(30))