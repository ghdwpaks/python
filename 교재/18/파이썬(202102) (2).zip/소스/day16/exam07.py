list_data = ['key01','key02','key03','key04']

dict_data = {}.fromkeys(list_data)
print('dict_data : ', dict_data)

dict_data = {}.fromkeys(list_data, 1)
print('dict_data : ', dict_data)