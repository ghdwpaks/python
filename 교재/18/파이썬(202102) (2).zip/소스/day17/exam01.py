list_data1 = [1, 2, 3]
list_data2 = list_data1

print(list_data1)
print(list_data2)
print('-'*8)
list_data1.clear()
print(list_data1)
print(list_data2)