dict_data1 = {'id' : 'kyes'}
dict_data2 = dict_data1

print(dict_data1)
print(dict_data2)

print('-'*8)

dict_data1.clear()
print(dict_data1)
print(dict_data2)