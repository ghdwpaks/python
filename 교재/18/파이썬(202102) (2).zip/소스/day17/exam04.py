tuple_data1 = (1, 2, 3)
tuple_data2 = tuple_data1

print(tuple_data1)
print(tuple_data2)

print('-'*8)

tuple_data1 = (4, 5, 6)
print(tuple_data1)
print(tuple_data2)