data1 = 3.1; data2 = 3
# ; 문장의 끝
print('data1 > data2 :', data1 > data2)
print('data1 >= data2 :', data1 >= data2)

print('data1 != data2 :', data1 != data2)
print('data1 == data2 :', data1 == data2)

print('data1 < data2 :', data1 < data2)
print('data1 <= data2 :', data1 <= data2)
