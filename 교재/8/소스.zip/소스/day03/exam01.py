#알파벳, 숫자, 언더스코어(_)로 구성
int_data = 10
int_data2 = 20

# 영어 대/소문자를 구분
intData = 10
intdata = 20
print('intData :', intData)
print('intdata :', intdata)

#한글 사용 가능하나, 영어 대/소문자를 쓴다.
코끼리 = '코끼리'

#변수명의 시작은 숫자로 할 수 없음
#1intData = 10  (x)
intData1 = 10 # (0)

#공백이나 특수 기호는 포함 할 수 없음
# big data = 10
# bigd@ta = 20

#Python 예약어는 사용하면 안된다.
#print, if, for, while .. 
#if = 10
#print(if)
#print = 100
#print(10)

# naming conventions
smallData = 1 # camel
small_data = 2 # snake 
SmallData = 3 # Pascal