data1 = 9
data2 = 2

print('{} + {} = {}'.format(data1, data2, data1+data2))
print('{} - {} = {}'.format(data1, data2, data1-data2))
print('{} * {} = {}'.format(data1, data2, data1*data2))
print('{} / {} = {}'.format(data1, data2, data1/data2))
print('{} // {} = {}'.format(data1, data2, data1//data2))
print('{} % {} = {}'.format(data1, data2, data1%data2))
print('{} ** {} = {}'.format(data1, data2, data1**data2))
