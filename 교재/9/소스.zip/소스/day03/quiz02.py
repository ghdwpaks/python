# data1 = 7, data2 = 5를 입력하고 
# +, -, *, / 등의 사칙연산 결과를 출력하시오.
data1 = 7;
data2 = 5;
sum_data = data1 + data2
sub_data = data1 - data2
mul_data = data1 * data2
div_data = data1 / data2

print('data1({}) + data2({}) = {}'.format(data1, data2, sum_data))
print('data1({}) - data2({}) = {}'.format(data1, data2, sub_data))
print('data1({}) * data2({}) = {}'.format(data1, data2, mul_data))
print('data1({}) / data2({}) = {}'.format(data1, data2, div_data))