data1 = 1

# 멤버 연산자
result = data1 in ('1',2,3)
print('{} in (1,2,3) : {}'.format(data1, result))

result = data1 not in ('1',2,3)
print('{} not in (1,2,3) : {}'.format(data1, result))



